import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-rating',
  templateUrl: './driver-rating.page.html',
  styleUrls: ['./driver-rating.page.scss'],standalone:false
})
export class DriverRatingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
