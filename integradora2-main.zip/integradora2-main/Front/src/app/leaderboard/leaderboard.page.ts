import { Component } from '@angular/core';

@Component({
  selector: 'app-leaderboard',
  templateUrl: 'leaderboard.page.html',
  styleUrls: ['leaderboard.page.scss'],
  standalone:false
})
export class LeaderboardPage {
  drivers = [
    { name: 'Chofer 1', score: 4.8 },
    { name: 'Chofer 2', score: 4.7 },
    { name: 'Chofer 3', score: 4.6 },
  ];
}