import { Component, OnInit } from '@angular/core';
import * as L from 'leaflet';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false
})
export class HomePage implements OnInit {
  private map: L.Map | undefined; // Usar L.Map y permitir 'undefined'

  constructor() {}

  ngOnInit() {
    this.initMap();
  }

  private initMap() {
    const aguascalientesCoords: L.LatLngExpression = [21.8853, -102.2916];
    this.map = L.map('map').setView(aguascalientesCoords, 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    }).addTo(this.map);

  }
}