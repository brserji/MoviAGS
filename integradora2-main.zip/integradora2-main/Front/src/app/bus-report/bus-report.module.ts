import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BusReportPageRoutingModule } from './bus-report-routing.module';

import { BusReportPage } from './bus-report.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BusReportPageRoutingModule
  ],
  declarations: [BusReportPage]
})
export class BusReportPageModule {}
