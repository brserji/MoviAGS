import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BusReportPage } from './bus-report.page';

const routes: Routes = [
  {
    path: '',
    component: BusReportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BusReportPageRoutingModule {}
