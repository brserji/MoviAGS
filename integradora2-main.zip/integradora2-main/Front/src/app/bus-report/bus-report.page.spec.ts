import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BusReportPage } from './bus-report.page';

describe('BusReportPage', () => {
  let component: BusReportPage;
  let fixture: ComponentFixture<BusReportPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(BusReportPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
