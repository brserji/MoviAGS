import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bus-report',
  templateUrl: './bus-report.page.html',
  styleUrls: ['./bus-report.page.scss'],
  standalone:false
})
export class BusReportPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
